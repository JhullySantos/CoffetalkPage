gsap.from('.home-img', {opacity: 0, duration:2, delay:.5, x:60});
gsap.from('.home-text', {opacity: 0, duration:2, delay:.8, y:60});
gsap.from('.titulo, .nav-menu', {opacity: 0, duration:1, delay:1.5, y:25, ease:'expo.out', stagger:.1});

// page sobre
gsap.from('.sobre-p1', {opacity: 0, duration:2, delay:.8, y:60});
gsap.from('.sobre-p2', {opacity: 0, duration:2, delay:.8, y:60});
gsap.from('.sobre-p3', {opacity: 0, duration:2, delay:.8, y:60});v
gsap.from('.gameplay1, .gameplay2, .gameplay3', {opacity: 0, duration:2, delay:.5, x:60});
